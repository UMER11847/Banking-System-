#pragma once
using namespace System;
using namespace System::IO;

ref class  Admin
{
public:
	String^ Username;
	String^ Pass;
};
