#pragma once
using namespace System;
using namespace System::IO;

ref class Transaction
{
public:
	Int32^ Transid;
	Int32^ TransACCno;
	String^ Type;
	Double^ Amount;
	String^ Date_Time;
};


