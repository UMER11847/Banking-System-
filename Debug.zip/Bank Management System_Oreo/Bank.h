#pragma once
using namespace System;
using namespace System::IO;

ref class Bank{
public:
	String^ bank_name;
};


