#pragma once

#include "string"
#include "iostream"
#include "Employee.h"
#include "Loan.h"
#include "Admin.h"
#include "Bank.h"
#include "Transaction.h"
#include "Account.h"
#include "Customer.h"
#include "Person.h"
ref class Mapper
{




	public:
		static array<Employee^>^ map_employee(array<String^>^ rows)
		{

			array<Employee^>^ ob = gcnew array<Employee^>(rows->Length);

			for (int i = 0;i < rows->Length;i++)
			{
				array<String^>^ temp = rows[i]->Split(',');
				ob[i] = gcnew Employee();
				ob[i]->Empid = temp[0];

			}

			return ob;

		}

		static array<Loan^>^ map_loan(array<String^>^ rows)
		{

			array<Loan^>^ ob = gcnew array<Loan^>(rows->Length);

			for (int i = 0;i < rows->Length;i++)
			{
				array<String^>^ temp = rows[i]->Split(',');
				ob[i] = gcnew Loan();
				ob[i]->Loanid = temp[0];
				ob[i]->Accountno = temp[1];
				ob[i]->Loanamount = Double::Parse(temp[2]);
				ob[i]->Interestrate = temp[3];
				ob[i]->Outstandingbalance = temp[4];
				ob[i]->Date = temp[5];
			}

			return ob;

		}

		static array<Admin^>^ map_Admin(array<String^>^ rows)
		{

			array<Admin^>^ ob = gcnew array<Admin^>(rows->Length);

			for (int i = 0;i < rows->Length;i++)
			{
				array<String^>^ temp = rows[i]->Split(',');
				ob[i] = gcnew Admin();
				ob[i]->Username = temp[0];
				ob[i]->Pass = temp[1];

			}

			return ob;

		}

		static array<Bank^>^ map_Bank(array<String^>^ rows)
		{

			array<Bank^>^ ob = gcnew array<Bank^>(rows->Length);

			for (int i = 0;i < rows->Length;i++)
			{
				array<String^>^ temp = rows[i]->Split(',');
				ob[i] = gcnew Bank();
				ob[i]->bank_name = temp[0];

			}

			return ob;

		}

		static array<Transaction^>^ map_Transaction(array<String^>^ rows)
		{

			array<Transaction^>^ ob = gcnew array<Transaction^>(rows->Length);

			for (int i = 0;i < rows->Length;i++)
			{
				array<String^>^ temp = rows[i]->Split(',');
				ob[i] = gcnew Transaction();
				ob[i]->Transid = Int32::Parse(temp[0]);
				ob[i]->TransACCno = Int32::Parse(temp[1]);
				ob[i]->Type = temp[2];
				ob[i]->Amount = double::Parse(temp[3]);
				ob[i]->Date_Time = temp[4];



			}


			return ob;

		}


		static array<Account^>^ map_Account(array<String^>^ rows)
		{

			array<Account^>^ ob = gcnew array<Account^>(rows->Length);

			for (int i = 0;i < rows->Length;i++)
			{
				array<String^>^ temp = rows[i]->Split(',');
				ob[i] = gcnew Account();
				ob[i]->accno = temp[0];
				ob[i]->acctype = temp[1];
				ob[i]->Balance = double::Parse(temp[2]);
				ob[i]->status = System::Convert::ToBoolean(temp[3]);


					return ob;
			}
		}


		static array<Customer^>^ map_Customer(array<String^>^ rows)
		{

			array<Customer^>^ ob = gcnew array<Customer^>(rows->Length);

			for (int i = 0;i < rows->Length;i++)
			{
				array<String^>^ temp = rows[i]->Split(',');
				ob[i] = gcnew Customer();
				ob[i]->customerid = temp[0];
			}

			return ob;

		}

		static array<Person^>^ map_Person(array<String^>^ rows)
		{

			array<Person^>^ ob = gcnew array<Person^>(rows->Length);

			for (int i = 0;i < rows->Length;i++)
			{
				array<String^>^ temp = rows[i]->Split(',');
				ob[i] = gcnew Person();
				ob[i]->Name= temp[0];
				ob[i]->Address = temp[1];
				ob[i]->Contactno = temp[2];
				ob[i]->Email = temp[3];

			}



			return ob;

		}
	};




