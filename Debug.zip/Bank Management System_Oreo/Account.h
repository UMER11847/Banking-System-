#pragma once
using namespace System;
using namespace System::IO;

ref class Account {
public:
	String^ accno;
	String^ acctype;
	double^ Balance;
	bool^ status;


};

