  ,#pragma once
using namespace System;
using namespace System::IO;

ref class Loan
{
public:
	String^ Loanid;
	String^ Accountno;
	Double^ Loanamount ;
	String^ Interestrate;
	String^ Outstandingbalance;
	String^ Date;

};


