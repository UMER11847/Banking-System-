#pragma once
using namespace System;
using namespace System::IO;

ref class Employee
{
public:
	String^ Empid;
};
