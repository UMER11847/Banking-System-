#pragma once
using namespace System;
using namespace System::IO;

ref class Person
{
public:
	String^ Name;
	String^ Address;
	String^ Contactno;
	String^ Email;
};

