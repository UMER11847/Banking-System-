#pragma once
using namespace System;
using namespace System::IO;
ref class Customer
{
public:
	String^ customerid;


};

